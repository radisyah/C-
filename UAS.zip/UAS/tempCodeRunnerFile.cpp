
  cout << "SelectionSort" << endl;
  selectionSort(angka);
  for (int i= 0; i < 100; i++){
  cout << angka[i] << " ";
  }
  cout << endl;
